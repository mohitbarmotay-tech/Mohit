function Sumnumber(){

    let num=100;
    let sum=0;

    for(let i=0; i<=100; i++){

sum=sum+i;

    }

document.getElementById('num').innerHTML="sum of first 100 number = " + sum;
}