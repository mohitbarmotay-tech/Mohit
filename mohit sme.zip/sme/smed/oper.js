function Operator(){
    let oper='+';
    let x=20,y=10;

    switch (oper) {

        case value'+' : x+y;break;
    case value'-': x-y;break;
    case value'*': x*y;break;
      case value'/': x/y;break;
        default:
            break;
    }
}