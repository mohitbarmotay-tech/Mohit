function Sumeven(){
  let sum=0;
  for( let i=0; i<=50; i++){

    if(i%2==0){
        sum=sum+i;
    }
  }

document.getElementById('num').innerHTML=" sum of first 50 even number =" +sum;


}