function marks(){
    let name= "raj";
    let roll=25100110086;
    let subject1=86;
    let subject2=85;
    let subject3=68;
    let subject4=81;
    let subject5=99;
    let total_marks=subject1+subject2+subject3+subject4+subject5;
    let percentage=total_marks/5;

    let display= "name = "+name+ "roll ="+roll + "total marks="+total_marks+ "percentage = "+percentage;

    document.getElementById('demo').innerHTML="sudent details:-"+display;







}