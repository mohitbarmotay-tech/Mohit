function Factorial(){

    let num=prompt("enter a number...");
    let fact=1;

    for(i=1; i<=num; i++){
fact=fact*i;
    }
document.getElementById('demo').innerHTML="factorial = " + fact;

    }









