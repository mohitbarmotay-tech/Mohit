function Table(){
 let num=prompt("enter a number");
 let text="";
 for(let i=1; i<=10; i++){
    text +=num+ "*"+i+ "=" +(num*i) +"<br>";

 }
 document.getElementById('num').innerHTML = text;
}






