function checkNumber(){
 let num=prompt("enter a number");
 if(num>0)
 {
document.getElementById('check').innerHTML="number is positive...";
 }
 else if(num=0){
    document.getElementById('check').innerHTML="number is equal to zero...";
 }
 else{
document.getElementById('check').innerHTML="number is negative...";
 }
}





