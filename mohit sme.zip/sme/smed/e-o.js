function checkNumber(){
    let num=prompt("enter a number");
 if(num%2)
 {
document.getElementById('check').innerHTML="number is even";
 }
 else{
    document.getElementById('check').innerHTML="number is odd";
 }
}