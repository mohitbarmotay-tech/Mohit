function sum(){
    let arr=[2,3,5,8,9,4,6,7];
    let sum= 0;
    for( let i=0; i<arr.length; i++){
        sum=sum + arr[i];

}
console.log("sum of array:"+ sum);
}