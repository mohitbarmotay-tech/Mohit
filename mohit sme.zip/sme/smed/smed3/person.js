function persona()
{
     const person={
firstName:"Raj",
lastName:"kumar",
age:20,
fullName: function() {
     return this.firstName + " " + this.lastName;
}


     };
     console.log(person.firstName);
console.log(person.age);
console.log(person.fullName());


}