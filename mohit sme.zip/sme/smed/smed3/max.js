function maxarray(){
    let arr=[15,5,6,8,7,9,2,3,11,99,77]
     let max= arr[0];
    for(let i=0; i<arr.length; i++){
        if(arr[i]>max){
            max = arr[i];
        }
    }
    console.log("maximum value is:-"+max);
}