function even(){

let arr=[2,8,9,6,4,3,7];
   

for(let i=0; i<arr.length; i++){
    if(arr[i]%2==0){
    console.log(arr[i]);
}}}
