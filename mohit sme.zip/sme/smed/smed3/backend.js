async function fetchData(){
   try {
    const response = await fetch ('https://typicode.com');
    if (!response.ok){
        throw new Error('HTTP error! status:$(response.status}');
    }
    const data= await response.json();
    console.log(data);
   }
catch(error){
    console.error('fetch error:',error.message);
}
}
fetchData();