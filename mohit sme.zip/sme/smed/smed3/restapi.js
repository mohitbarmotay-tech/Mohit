let api = "https://dummy.restapiexample.com/api/v1";
function loadEmpolyees(){
     fetch(api+"/employees")
     .then(response => response.json())
     .then(data => {
        document.getElementById("output").innerText= JSON.stringify(data, null, 2);
     });

}
function searchEmployee(){
    let id = document.getElementById("searchId").value;
    fetch (api + "/employee/" + id )
    .then(response => response.json())
    .then(data => {
        document.getElementById("output").innerText= JSON.stringify(data, null, 2);
    });
}
function addEmployee(){
    let employee = {
        name:document.getElementById("name").value,
         salary:document.getElementById("salary").value,
          age:document.getElementById("age").value
    };
    fetch(api + "/create",{
        method:"POST",
        headers:{
            "Content-Type":"application/json"
        },
    })
    .then(response => response.json())
    .then(data => {
        document.getElementById("output").innerText = JSON.stringify(Data, null, 2);
    });
}
function updateEmployee(){
    let id = document.getElementById("updateId").value;
    let employee = {
        name:document.getElementById("updateName").value

    };
    fetch(api + "/update/" +id,{
        method:"PUT",
        headers:{
            "Content-Type":"application/json"
        },
        body: JSON.stringify(employee)
    })
    .then(response=>response.json())
    .then(data=>{
        document.getElementById("output").innerText=JSON.stringify(data,null,2);
    });
}
function deleteEmployee(){
    let id=document.getElementById("deletwId").value;

    fetch(api+"/delete/"+id,{
     method:"DELETE"
    })
    .then(response=>response.json())
    .then(data=>{
        document.getElementById("output").innerText=JSON.stringify(data,null,2);
    });
}