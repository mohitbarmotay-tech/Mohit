function validation(){



    let name=document.forms["myform"]["sname"].value;
let rollno=document.forms["myform"]["srollno"].value;
 let email =document.forms["myform"]["semail"].value;
let password=document.forms["myform"]["spassword"].value;
let confirm=document.forms["myform"]["sconfirm"].value;

    if(name=="" && rollno=="" && email=="" ){
     alert("name and rollno must be filled out");
        return false;
    }
    else if(name.length < 3){
        alert("please enter full name");
    }
    else if( password!=confirm){
        alert("password do not match");
        return false;
    }
    else{
        alert("signup successfull");
        return true;
    }
}
