function array(){
  const car= []
    car[0]="buggati";
    car[1]="bmw M4";
    car[2]="audi";
    car[3]="skoda";
    car[4]="mrcedes";
    for( let i=0; i<5; i++)
        console.log(car[i]);
}