function miniarray(){
    let arr=[ 10,5 ,9 , 6 , 8,4,3];
    let min= arr[0];
    for(let i=0; i<arr.length; i++){
        if(arr[i]<min){
            min = arr[i];
        }
    }
    console.log("minimum value is;-"+min);
}