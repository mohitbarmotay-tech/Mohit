const form = document.getElementById('studentForm');
const message = document.getElementById('message');
const pages = {
  dashboard: document.getElementById('dashboardPage'),
  add: document.getElementById('addPage'),
  students: document.getElementById('studentsPage'),
  search: document.getElementById('searchPage'),
  delete: document.getElementById('deletePage')
};

// Demo data makes the portal look populated on first launch.
let students = [
  { id: 1, name: 'Aditi Sharma', phone: '9876543210', email: 'aditi@stu.com', gender: 'Female', course: 'B.Tech CSE', dob: '', status: 'Active' },
  { id: 2, name: 'Rohan Mehta', phone: '9876501234', email: 'rohan@stu.com', gender: 'Male', course: 'B.Tech ECE', dob: '', status: 'Active' },
  { id: 3, name: 'Sneha Patel', phone: '9812345670', email: 'sneha@stu.com', gender: 'Female', course: 'B.Sc CS', dob: '', status: 'Active' }
];
let nextId = 4;

document.querySelectorAll('.nav-link').forEach(button => {
  button.addEventListener('click', () => showPage(button.dataset.page));
});

function showPage(pageName) {
  Object.entries(pages).forEach(([name, element]) => {
    element.classList.toggle('hidden', name !== pageName);
  });
  document.querySelectorAll('.nav-link').forEach(button => {
    button.classList.toggle('active', button.dataset.page === pageName);
  });
  if (pageName === 'dashboard') renderDashboard();
  if (pageName === 'students') renderStudents();
  if (pageName === 'delete') renderDeleteTable();
}

form.addEventListener('submit', event => {
  event.preventDefault();
  const data = new FormData(form);
  const student = {
    id: nextId++,
    name: data.get('name').trim(),
    phone: data.get('phone').trim(),
    email: data.get('email').trim(),
    gender: data.get('gender'),
    course: data.get('course'),
    dob: data.get('dob'),
    status: 'Active'
  };

  if (!student.name || !student.email || !student.gender || !student.course) {
    showMessage('Please fill in all required fields.', 'error');
    return;
  }
  if (students.some(item => item.email.toLowerCase() === student.email.toLowerCase())) {
    showMessage('A student with this email already exists.', 'error');
    return;
  }

  students.unshift(student);
  form.reset();
  showMessage('Student saved successfully!', 'success');
});

form.addEventListener('reset', () => {
  message.textContent = '';
  message.className = 'message';
});

function showMessage(text, type) {
  message.textContent = text;
  message.className = `message ${type}`;
}

function escapeHTML(value) {
  return String(value ?? '').replace(/[&<>"']/g, char => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[char]));
}

function studentTable(list, includeActions = false) {
  if (!list.length) return '<p class="muted">No students found.</p>';
  return `<table>
    <thead><tr><th>ID</th><th>Name</th><th>Course</th><th>Email</th><th>Phone</th><th>Gender</th>${includeActions ? '<th>Action</th>' : '<th>Status</th>'}</tr></thead>
    <tbody>${list.map(student => `<tr>
      <td>${student.id}</td><td>${escapeHTML(student.name)}</td><td>${escapeHTML(student.course)}</td>
      <td>${escapeHTML(student.email)}</td><td>${escapeHTML(student.phone || '—')}</td><td>${escapeHTML(student.gender)}</td>
      ${includeActions
        ? `<td><button class="btn table-action delete-btn" data-delete-id="${student.id}">Delete</button></td>`
        : '<td>Active</td>'}
    </tr>`).join('')}</tbody>
  </table>`;
}

function renderStudents() {
  document.getElementById('studentsTable').innerHTML = studentTable(students);
}

function renderDeleteTable() {
  const container = document.getElementById('deleteTable');
  container.innerHTML = studentTable(students, true);
  container.querySelectorAll('[data-delete-id]').forEach(button => {
    button.addEventListener('click', () => {
      const id = Number(button.dataset.deleteId);
      const student = students.find(item => item.id === id);
      if (student && confirm(`Delete ${student.name} from the student list?`)) {
        students = students.filter(item => item.id !== id);
        renderDeleteTable();
      }
    });
  });
}

function renderDashboard() {
  document.getElementById('totalCount').textContent = students.length;
  document.getElementById('activeCount').textContent = students.filter(s => s.status === 'Active').length;
  document.getElementById('maleCount').textContent = students.filter(s => s.gender === 'Male').length;
  document.getElementById('femaleCount').textContent = students.filter(s => s.gender === 'Female').length;
  document.getElementById('recentStudents').innerHTML = studentTable(students.slice(0, 5));
}

function searchStudents() {
  const query = document.getElementById('searchInput').value.trim().toLowerCase();
  const results = students.filter(student =>
    student.name.toLowerCase().includes(query) || student.email.toLowerCase().includes(query)
  );
  const container = document.getElementById('searchResults');
  if (!query) {
    container.innerHTML = '<p class="muted">Please enter a name or email to search.</p>';
  } else if (!results.length) {
    container.innerHTML = '<p class="muted">No matching student found.</p>';
  } else {
    container.innerHTML = results.map(student => `
      <div class="search-card">
        <div class="avatar">●</div>
        <div>
          <p><strong>Name:</strong> ${escapeHTML(student.name)}</p>
          <p><strong>Email:</strong> ${escapeHTML(student.email)}</p>
          <p><strong>Course:</strong> ${escapeHTML(student.course)}</p>
          <p><strong>Gender:</strong> ${escapeHTML(student.gender)}</p>
          <p><strong>Phone:</strong> ${escapeHTML(student.phone || '—')}</p>
        </div>
      </div>`).join('');
  }
}
document.getElementById('searchButton').addEventListener('click', searchStudents);
document.getElementById('searchInput').addEventListener('keydown', event => {
  if (event.key === 'Enter') searchStudents();
});
document.getElementById('searchInput').addEventListener('input', searchStudents);

// Start on the Add Student form, matching the supplied reference image.
showPage('add');
